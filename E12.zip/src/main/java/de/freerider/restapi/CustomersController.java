//5.) Entfernen Sie im REST‐Interface in CustomersController.java die Mock‐Daten (class Person{ } usw. ), 
//so dass nur die Implementierungsmethoden aus CustomersAPI.java übrig sind. 
//Fügen Sie eine @Autowired Variable: customerRepository ein und ersetzen Sie die JSON Datenrückgabe 
//in getCustomers() und getCustomer( long id ), so dass Daten aus dem Repository ausgeliefert werden. 

package de.freerider.restapi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import de.freerider.datamodel.Customer;
import de.freerider.repository.CustomerRepository;
import de.freerider.restapi.ServiceController.Person;

@RestController
public class CustomersController implements CustomersAPI {  //was soll entfernt sein?

	private final ObjectMapper objectMapper;
	//Customer cus = new Customer();
	//private final List<Customer> cus = new ArrayList<Customer>();
	private final HttpServletRequest request;

	public CustomersController(ObjectMapper objectMapper, HttpServletRequest request) {
		this.objectMapper = objectMapper;
		this.request = request;
	}

	@Autowired
	CustomerRepository customerRepository; 

	//	create customers like people from service Controller
	@Override
	public ResponseEntity<List<?>> getCustomers() {


		customerRepository.findAll();
		ResponseEntity<List<?>> re = null;
		System.err.println( request.getMethod() + " " + request.getRequestURI() );   
		try {
			ArrayNode arrayNode = serializeCustomersAsJSON();
			ObjectReader reader = objectMapper.readerFor( new TypeReference<List<ObjectNode>>() { } );
			List<String> list = reader.readValue( arrayNode );
			//
			re = new ResponseEntity<List<?>>( list, HttpStatus.OK );

		} catch( IOException e ) {
			re = new ResponseEntity<List<?>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return re;

	}

	//person arraylist 



	@Override
	public ResponseEntity<ObjectNode> getCustomer(long id) {

		ResponseEntity<ObjectNode> re = null;

		System.err.println( request.getMethod() + " " + request.getRequestURI() );   
		re = new ResponseEntity<ObjectNode>(HttpStatus.NOT_FOUND);

		Optional<Customer> customer = customerRepository.findById(id);


		if(customer.isPresent()) {
			ObjectNode jsonNode = serializeCustomerAsJSON(customer.get());
			//					ObjectReader reader = objectMapper.readerFor( new TypeReference<List<ObjectNode>>() { } );
			//					List<String> list = reader.readValue( jsonNode );
			//}
			re = new ResponseEntity<ObjectNode>( jsonNode, HttpStatus.OK );


		} else{
			re = new ResponseEntity<ObjectNode>(HttpStatus.NOT_FOUND);
		}

		return re;


	}

	//	class Customer {
	//		String firstName = "";
	//		String lastName = "";
	//		final List<String> contacts = new ArrayList<String>();
	//		int id = 0;
	//
	//		Customer setName( String firstName, String lastName ) {
	//			this.firstName = firstName;
	//			this.lastName = lastName;
	//			return this;
	//		}
	//
	//		public long getId() {
	//			// TODO Auto-generated method stub
	//			return id;
	//		}
	//
	//		Customer setFirstName( String firstName) {
	//			this.firstName = firstName;
	//
	//			return this;
	//		}
	//
	//		Customer addContact( String contact ) {
	//			this.contacts.add( contact );
	//			return this;
	//		}
	//
	//		Customer setID(int id) {
	//			this.id = id;
	//			return this;
	//		}
	//	}
	//


	//	private final Customer eric = new Customer()
	//			.setName( "Eric", "Meyer" )
	//			.addContact( "eric98@yahoo.com" )
	//			.addContact( "(030) 3945-642298" )
	//			.setID(1);
	//	//
	//	private final Customer anne = new Customer()
	//			.setName( "Anne", "Bayer" )
	//			.addContact( "anne24@yahoo.de" )
	//			.addContact( "(030) 3481-23352" )
	//			.setID(2);
	//	//
	//	private final Customer tim = new Customer()
	//			.setName( "Tim", "Schulz-Mueller" )
	//			.addContact( "tim2346@gmx.de" )
	//			.setID(3);



	private ArrayNode serializeCustomersAsJSON() { //changes the java list to json object
		//
		final Iterable<Customer> customer = customerRepository.findAll();
		ArrayNode arrayNode = objectMapper.createArrayNode();
		//
		customer.forEach( c -> {
			StringBuffer sb = new StringBuffer();
			c.getContacts().forEach( contact -> sb.append( sb.length()==0? "" : "; " ).append( contact ) );
			arrayNode.add(
					objectMapper.createObjectNode()
					.put( "Lname", c.getLastName())
					.put( "Fname", c.getFirstName())
					.put( "contacts", sb.toString())
					.put("id", c.getId())
					);
		});
		return arrayNode;
	}

	private ObjectNode serializeCustomerAsJSON(Customer c) { //changes the java list to json object
		//
		ObjectNode jsonNode = objectMapper.createObjectNode();
		//StringBuffer sb = new StringBuffer();
		//
		//		customer.forEach( c -> {
		StringBuffer sb = new StringBuffer();
		c.getContacts().forEach( contact -> sb.append( sb.length()==0? "" : "; " ).append( contact ) );
		//			((ObjectNode) jsonNode)(
		//				objectMapper.createObjectNode()
		jsonNode.put( "name", c.getLastName());
		jsonNode.put( "name", c.getFirstName());
		jsonNode.put( "contacts", sb.toString());
		jsonNode.put("id", c.getId());
		//);
		//		});


		return jsonNode;
	}

	@Override
	public ResponseEntity<List<?>> postCustomers(Map<String, Object>[] jsonMap) {
		// TODO Auto-generated method stub
		System.err.println( "POST /customers" );
		if( jsonMap == null )
			return new ResponseEntity<>( null, HttpStatus.BAD_REQUEST );
		//
		System.out.println( "[{" );
		for( Map<String, Object> kvpairs : jsonMap ) {
			kvpairs.keySet().forEach( key -> {		
				Object value = kvpairs.get( key );
				System.out.println( "  [ " + key + ", " + value + " ]" );
			});
		}
		System.out.println( "}]" );
		return new ResponseEntity<>( null, HttpStatus.OK );
	}

	@Override
	public ResponseEntity<List<?>> putCustomers(Map<String, Object>[] jsonMap) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<?> deleteCustomer(long id) {
		// TODO Auto‐generated method stub
		try {
			System.err.println( "DELETE /customers/" + id );
			return new ResponseEntity<>( null, HttpStatus.ACCEPTED ); // status 202
		} catch (Exception e) {
			return new ResponseEntity<List<?>>(HttpStatus.NOT_FOUND);
		}
	}

	private Optional<Customer> accept( Map<String, Object> kvpairs ) {
		// ...
		AtomicBoolean name = new AtomicBoolean(false);
		AtomicBoolean first = new AtomicBoolean(false);
		AtomicBoolean id = new AtomicBoolean(false);

		Customer cus = null;

		if(kvpairs == null) {
			return Optional.empty();
		} else {
			Set<String> keys = kvpairs.keySet();

			for(String key: kvpairs.keySet()) {
				if(key.equals("id")) {
					String idString = kvpairs.get("id").toString();
					if (Long.parseLong(idString) >= 0) {
						id.set(true);
					} else {
						id.set(false);
						Long idNew = Long.valueOf((long) (Math.random() * 10000.0));

						while(kvpairs.containsKey(id)) {
							idNew = Long.valueOf((long) (Math.random() * 10000.0));
						}

					}
				}
			}

			Object nameString = kvpairs.get("name");
			Object fnameString = kvpairs.get("fname");

			if(nameString != null && fnameString != null) {
				first.set(true);
				name.set(true);
			} else {

				first.set(false);
				name.set(false);
			}

			return Optional.of(cus) ;
		}

	}

}
