package de.freerider.datamodel;

public enum Status {

	    New,
	    InRegistration,
	    Active,
	    Suspended,
	    Deleted
}
